export class Company {
    _id: string;
    name: string;
}
