import { Product } from './products.service';

export class Item {

    constructor(public product:Product,public quantity:number){}

 }